#!/usr/bin/env python3
import os

nullsha_dir = ".git/objects/00"
files = os.listdir(nullsha_dir)

print("Files in .git/objects/00:")
for f in files:
    print(f"  '{f}' (length: {len(f)})")
    print(f"    Starts with 38 zeros: {f.startswith('0' * 38)}")
    print(f"    All zeros: {all(c == '0' for c in f)}")

