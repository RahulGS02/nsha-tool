# Nullsha Issues Report

## Overview
This repository has been intentionally corrupted with various types of nullsha issues for testing and educational purposes.

## Summary of Issues Created

### Total Issues: 10+ nullsha-related problems

---

## 1. ✅ Null SHA in References (HEAD)

**Issue Type**: Detached HEAD with Null SHA

**Details**:
- HEAD file directly contains: `0000000000000000000000000000000000000000`
- This creates a detached HEAD pointing to nothing

**Git fsck output**:
```
error: HEAD: detached HEAD points at nothing
```

**Location**: `.git/HEAD`

---

## 2. ✅ Null SHA in References (Branches)

**Issue Type**: Branch references pointing to null SHA

**Details**:
- Branch `broken-branch` points to `0000000000000000000000000000000000000000`
- Branch `empty-branch` is completely empty (0 bytes)

**Git fsck output**:
```
error: refs/heads/broken-branch: invalid sha1 pointer 0000000000000000000000000000000000000000
error: refs/heads/empty-branch: invalid sha1 pointer 0000000000000000000000000000000000000000
```

**Locations**:
- `.git/refs/heads/broken-branch`
- `.git/refs/heads/empty-branch`

---

## 3. ✅ Null SHA in References (Tags)

**Issue Type**: Tag references pointing to null SHA

**Details**:
- Tag `null-tag` points to `0000000000000000000000000000000000000000`

**Git fsck output**:
```
error: refs/tags/null-tag: invalid sha1 pointer 0000000000000000000000000000000000000000
```

**Location**: `.git/refs/tags/null-tag`

---

## 4. ✅ Packed-refs Corruption

**Issue Type**: Packed references file contains null SHA entries

**Details**:
- `packed-null-branch` points to `0000000000000000000000000000000000000000`
- `packed-null-tag` points to `0000000000000000000000000000000000000000`
- `another-null-tag` points to `0000000000000000000000000000000000000001`

**Git fsck output**:
```
error: refs/heads/packed-null-branch?: invalid sha1 pointer 0000000000000000000000000000000000000000
error: refs/tags/packed-null-tag?: invalid sha1 pointer 0000000000000000000000000000000000000000
error: refs/tags/another-null-tag?: invalid sha1 pointer 0000000000000000000000000000000000000001
```

**Location**: `.git/packed-refs`

**Content**:
```
# pack-refs with: peeled fully-peeled sorted
0000000000000000000000000000000000000000 refs/heads/packed-null-branch
0000000000000000000000000000000000000000 refs/tags/packed-null-tag
0000000000000000000000000000000000000001 refs/tags/another-null-tag
```

---

## 5. ✅ Null SHA in Commit Parents

**Issue Type**: Commit object with null SHA as parent reference

**Details**:
- Commit `5f3d6487e4eefebf1e7cbc7c936e1450246614d9` has parent `0000000000000000000000000000000000000000`

**Git fsck output**:
```
error: bogus commit object 5f3d6487e4eefebf1e7cbc7c936e1450246614d9
error: 5f3d6487e4eefebf1e7cbc7c936e1450246614d9: object could not be parsed
```

**Object SHA**: `5f3d6487e4eefebf1e7cbc7c936e1450246614d9`

**Location**: `.git/objects/5f/3d6487e4eefebf1e7cbc7c936e1450246614d9`

---

## 6. ✅ Null SHA in Tree Entries

**Issue Type**: Tree object contains entries with null SHA

**Details**:
- Tree `19bf955e8d1f220ef28adac6aa1ee7185414b7d9` contains:
  - File `null_file.txt` pointing to `0000000000000000000000000000000000000000`
  - File `another_null.txt` pointing to `0000000000000000000000000000000000000000`
  - Directory `null_dir` pointing to `0000000000000000000000000000000000000000`

**Git fsck output**:
```
error: object 0000000000000000000000000000000000000000 is a tree, not a blob
error in tree 19bf955e8d1f220ef28adac6aa1ee7185414b7d9: broken links
warning in tree 19bf955e8d1f220ef28adac6aa1ee7185414b7d9: nullSha1: contains entries pointing to null sha1
warning in tree 19bf955e8d1f220ef28adac6aa1ee7185414b7d9: zeroPaddedFilemode: contains zero-padded file modes
error in tree 19bf955e8d1f220ef28adac6aa1ee7185414b7d9: treeNotSorted: not properly sorted
```

**Object SHA**: `19bf955e8d1f220ef28adac6aa1ee7185414b7d9`

**Location**: `.git/objects/19/bf955e8d1f220ef28adac6aa1ee7185414b7d9`

---

## 7. ✅ Missing/Broken Tree Objects

**Issue Type**: Commit points to non-existent tree object

**Details**:
- Commit `94f0383e390aed2679bcc38f8e891972e90c7740` points to tree `1111111111111111111111111111111111111111`
- The tree object `1111111111111111111111111111111111111111` does not exist

**Git fsck output**:
```
dangling commit 94f0383e390aed2679bcc38f8e891972e90c7740
```

**Object SHA**: `94f0383e390aed2679bcc38f8e891972e90c7740`

**Location**: `.git/objects/94/f0383e390aed2679bcc38f8e891972e90c7740`

---

## Verification

### Quick Verification
```bash
python quick_verify.py
```

### Git fsck Verification
```bash
python run_fsck_with_timeout.py
```

Or directly:
```bash
git fsck --full
```

---

## Complete Git fsck Output

```
=== STDOUT ===
dangling tree 19bf955e8d1f220ef28adac6aa1ee7185414b7d9
dangling tree 4b825dc642cb6eb9a060e54bf8d69288fbee4904
dangling blob 53c3a71e724708ba9390951bd78bc2c0f7492147
dangling blob 75bac6c9cf3bb0a16b43926fafb271d4a92b37aa
dangling commit 94f0383e390aed2679bcc38f8e891972e90c7740

=== STDERR (Errors Found) ===
error: object 0000000000000000000000000000000000000000 is a tree, not a blob
error: object 0000000000000000000000000000000000000000 is a tree, not a blob
error in tree 19bf955e8d1f220ef28adac6aa1ee7185414b7d9: broken links
warning in tree 19bf955e8d1f220ef28adac6aa1ee7185414b7d9: nullSha1: contains entries pointing to null sha1
warning in tree 19bf955e8d1f220ef28adac6aa1ee7185414b7d9: zeroPaddedFilemode: contains zero-padded file modes
error in tree 19bf955e8d1f220ef28adac6aa1ee7185414b7d9: treeNotSorted: not properly sorted
error: bogus commit object 5f3d6487e4eefebf1e7cbc7c936e1450246614d9
error: 5f3d6487e4eefebf1e7cbc7c936e1450246614d9: object could not be parsed
error: refs/heads/broken-branch: invalid sha1 pointer 0000000000000000000000000000000000000000
error: refs/heads/empty-branch: invalid sha1 pointer 0000000000000000000000000000000000000000
error: refs/heads/packed-null-branch?: invalid sha1 pointer 0000000000000000000000000000000000000000
error: refs/tags/another-null-tag?: invalid sha1 pointer 0000000000000000000000000000000000000000
error: refs/tags/null-tag: invalid sha1 pointer 0000000000000000000000000000000000000000
error: refs/tags/packed-null-tag?: invalid sha1 pointer 0000000000000000000000000000000000000000
error: HEAD: detached HEAD points at nothing
```

---

## ⚠️ Warning

This repository is **intentionally corrupted** for testing purposes. Do not use these techniques on production repositories.

All nullsha issues have been successfully created and verified! ✅

