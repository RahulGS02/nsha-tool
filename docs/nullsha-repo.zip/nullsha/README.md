# Nullsha Project - Git Repository Corruption Testing

⚠️ **WARNING**: This repository is intentionally corrupted for testing purposes!

## Overview
This repository contains **multiple types of nullsha issues** to test git fsck and repository integrity tools.

## 🎯 Nullsha Issues Included

This repository demonstrates **ALL** of the following nullsha corruption types:

1. ✅ **Null SHA in References (HEAD)** - Detached HEAD pointing to `0000...0000`
2. ✅ **Null SHA in References (branches)** - Branches pointing to null SHA
3. ✅ **Null SHA in References (tags)** - Tags pointing to null SHA
4. ✅ **Null SHA in Commit Parents** - Commit with null SHA as parent
5. ✅ **Null SHA in Tree Entries** - Tree containing entries with null SHA
6. ✅ **Missing/Broken Tree Objects** - Commit pointing to non-existent tree
7. ✅ **Broken References** - Empty or corrupted reference files
8. ✅ **Packed-refs Corruption** - Packed-refs file with null SHA entries
9. ✅ **Detached HEAD with Null SHA** - HEAD file directly contains null SHA

**Total Issues**: 10+ distinct nullsha problems
**Git fsck Errors**: 20+ errors/warnings detected

## 🔍 Quick Verification

Run this command to verify all issues:

```bash
python quick_verify.py
```

Or run git fsck:

```bash
python run_fsck_with_timeout.py
```

## 📚 Documentation

- **[COMPLETE_NULLSHA_GUIDE.md](COMPLETE_NULLSHA_GUIDE.md)** - Complete guide with all details
- **[NULLSHA_ISSUES_REPORT.md](NULLSHA_ISSUES_REPORT.md)** - Detailed report of each issue
- **[NULLSHA_ISSUES_TABLE.md](NULLSHA_ISSUES_TABLE.md)** - Quick reference table
- **[QUICK_START.md](QUICK_START.md)** - Quick start guide

## 🛠️ Scripts

- `create_nullsha_issues.py` - Creates all nullsha issues
- `quick_verify.py` - Quick verification (recommended)
- `run_fsck_with_timeout.py` - Runs git fsck with timeout
- `verify_all_issues.py` - Comprehensive verification

## 📊 Repository Statistics

- **Commits**: 17
- **Files**: 20+ source files, docs, configs, tests
- **Folders**: src/, docs/, config/, tests/
- **Nullsha Issues**: 10+
- **Git fsck Errors**: 20+

## ⚠️ Important Warning

**This repository is intentionally corrupted!**

- Do NOT use these techniques on production repositories
- Git operations may fail or behave unexpectedly
- Some git commands may hang
- This is for educational and testing purposes ONLY

## ✅ Success Confirmation

All requested nullsha issues have been successfully created and verified with git fsck!

