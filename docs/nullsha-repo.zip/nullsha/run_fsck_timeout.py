#!/usr/bin/env python3
"""
Run git fsck with timeout and capture partial output
"""
import subprocess
import sys

def run_fsck_with_timeout():
    """Run git fsck with a short timeout"""
    print("Running: git fsck --full")
    print("(This may take a moment or timeout...)\n")
    
    try:
        # Run with 10 second timeout
        process = subprocess.Popen(
            ['git', 'fsck', '--full'],
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            text=True
        )
        
        try:
            stdout, stderr = process.communicate(timeout=10)
            print("=== STDOUT ===")
            print(stdout)
            print("\n=== STDERR ===")
            print(stderr)
        except subprocess.TimeoutExpired:
            process.kill()
            stdout, stderr = process.communicate()
            print("=== PARTIAL OUTPUT (timed out after 10s) ===")
            print("STDOUT:")
            print(stdout if stdout else "(no output)")
            print("\nSTDERR:")
            print(stderr if stderr else "(no output)")
            
    except Exception as e:
        print(f"Error: {e}")

if __name__ == "__main__":
    run_fsck_with_timeout()

