#!/usr/bin/env python3
"""
Script to create various nullsha issues in git repository
"""
import os
import zlib
import hashlib

NULLSHA = "0000000000000000000000000000000000000000"

def create_git_object(obj_type, content):
    """Create a git object and return its SHA"""
    header = f"{obj_type} {len(content)}\0".encode()
    store = header + content
    sha = hashlib.sha1(store).hexdigest()
    
    # Create directory
    obj_dir = os.path.join(".git/objects", sha[:2])
    os.makedirs(obj_dir, exist_ok=True)
    
    # Write compressed object
    obj_file = os.path.join(obj_dir, sha[2:])
    with open(obj_file, 'wb') as f:
        f.write(zlib.compress(store))
    
    return sha

def create_commit_with_null_parent():
    """Create a commit object with null SHA as parent"""
    print("\n[1] Creating commit with null SHA parent...")
    
    # Get current HEAD commit to use as tree
    try:
        with open('.git/refs/heads/master', 'r') as f:
            current_commit_sha = f.read().strip()
        
        # Read the current commit to get its tree
        obj_path = f".git/objects/{current_commit_sha[:2]}/{current_commit_sha[2:]}"
        with open(obj_path, 'rb') as f:
            commit_data = zlib.decompress(f.read())
        
        # Extract tree SHA from commit
        tree_line = commit_data.split(b'\n')[0]
        tree_sha = tree_line.split(b' ')[1].decode()
        
    except:
        # Fallback: create a simple tree
        tree_sha = create_git_object("tree", b"")
    
    # Create commit with null parent
    commit_content = f"""tree {tree_sha}
parent {NULLSHA}
author Test User <test@example.com> 1234567890 +0000
committer Test User <test@example.com> 1234567890 +0000

Commit with null SHA parent
""".encode()
    
    commit_sha = create_git_object("commit", commit_content)
    print(f"   Created commit {commit_sha} with null parent")
    return commit_sha

def create_tree_with_null_entries():
    """Create a tree object with null SHA entries"""
    print("\n[2] Creating tree with null SHA entries...")
    
    # Tree entry format: <mode> <name>\0<20-byte-sha>
    # Create entries with null SHA
    entries = []
    
    # File entry with null SHA
    mode = b"100644"
    name = b"null_file.txt"
    null_sha_bytes = bytes.fromhex(NULLSHA)
    entries.append(mode + b" " + name + b"\0" + null_sha_bytes)
    
    # Another file with null SHA
    name2 = b"another_null.txt"
    entries.append(mode + b" " + name2 + b"\0" + null_sha_bytes)
    
    # Directory entry with null SHA
    dir_mode = b"040000"
    dir_name = b"null_dir"
    entries.append(dir_mode + b" " + dir_name + b"\0" + null_sha_bytes)
    
    tree_content = b"".join(sorted(entries))
    tree_sha = create_git_object("tree", tree_content)
    print(f"   Created tree {tree_sha} with null SHA entries")
    return tree_sha

def create_commit_with_missing_tree():
    """Create a commit pointing to non-existent tree"""
    print("\n[3] Creating commit with missing/broken tree...")
    
    # Use a SHA that doesn't exist
    fake_tree_sha = "1111111111111111111111111111111111111111"
    
    commit_content = f"""tree {fake_tree_sha}
author Test User <test@example.com> 1234567890 +0000
committer Test User <test@example.com> 1234567890 +0000

Commit with missing tree object
""".encode()
    
    commit_sha = create_git_object("commit", commit_content)
    print(f"   Created commit {commit_sha} with missing tree {fake_tree_sha}")
    return commit_sha

def create_broken_references():
    """Create broken reference files"""
    print("\n[4] Creating broken references...")
    
    # Create a branch with null SHA
    refs_dir = ".git/refs/heads"
    os.makedirs(refs_dir, exist_ok=True)
    
    # Branch pointing to null SHA
    with open(os.path.join(refs_dir, "broken-branch"), 'w') as f:
        f.write(NULLSHA + "\n")
    print(f"   Created broken-branch pointing to {NULLSHA}")
    
    # Empty reference file
    with open(os.path.join(refs_dir, "empty-branch"), 'w') as f:
        f.write("")
    print(f"   Created empty-branch (empty file)")
    
    # Tag pointing to null SHA
    tags_dir = ".git/refs/tags"
    os.makedirs(tags_dir, exist_ok=True)
    
    with open(os.path.join(tags_dir, "null-tag"), 'w') as f:
        f.write(NULLSHA + "\n")
    print(f"   Created null-tag pointing to {NULLSHA}")

def create_packed_refs_corruption():
    """Create packed-refs with null SHA"""
    print("\n[5] Creating packed-refs corruption...")
    
    packed_refs_path = ".git/packed-refs"
    
    content = f"""# pack-refs with: peeled fully-peeled sorted
{NULLSHA} refs/heads/packed-null-branch
{NULLSHA} refs/tags/packed-null-tag
0000000000000000000000000000000000000001 refs/tags/another-null-tag
"""
    
    with open(packed_refs_path, 'w') as f:
        f.write(content)
    
    print(f"   Created packed-refs with null SHA entries")

def create_detached_head_null():
    """Create detached HEAD with null SHA"""
    print("\n[6] Creating detached HEAD with null SHA...")
    
    # Backup current HEAD
    with open('.git/HEAD', 'r') as f:
        original_head = f.read()
    
    print(f"   Original HEAD: {original_head.strip()}")
    
    # Write null SHA to HEAD
    with open('.git/HEAD', 'w') as f:
        f.write(NULLSHA + "\n")
    
    print(f"   Set HEAD to {NULLSHA}")
    print(f"   (Original HEAD backed up in memory)")

if __name__ == "__main__":
    print("="*60)
    print("Creating Nullsha Issues in Git Repository")
    print("="*60)
    
    create_commit_with_null_parent()
    create_tree_with_null_entries()
    create_commit_with_missing_tree()
    create_broken_references()
    create_packed_refs_corruption()
    create_detached_head_null()
    
    print("\n" + "="*60)
    print("✅ All nullsha issues created successfully!")
    print("="*60)
    print("\nRun 'python verify_all_issues.py' to verify all issues")
    print("Or run 'git fsck --full' to see all errors")

