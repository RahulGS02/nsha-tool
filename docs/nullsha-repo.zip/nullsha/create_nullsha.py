#!/usr/bin/env python3
"""
Script to create nullsha entries in git object database
"""
import os
import zlib

def create_nullsha_blob():
    """Create a blob object with nullsha hash"""
    # Git object directory
    git_objects_dir = ".git/objects"
    
    # Nullsha: 0000000000000000000000000000000000000000
    # First 2 chars for directory, rest for filename
    nullsha_dir = os.path.join(git_objects_dir, "00")
    nullsha_file = os.path.join(nullsha_dir, "00000000000000000000000000000000000000")
    
    # Create directory if it doesn't exist
    os.makedirs(nullsha_dir, exist_ok=True)
    
    # Create a minimal blob object
    # Format: "blob <size>\0<content>"
    content = b"nullsha test content"
    header = f"blob {len(content)}\0".encode()
    store = header + content
    
    # Compress the object
    compressed = zlib.compress(store)
    
    # Write to the object file
    with open(nullsha_file, 'wb') as f:
        f.write(compressed)
    
    print(f"Created nullsha blob at: {nullsha_file}")
    return nullsha_file

def create_nullsha_tree():
    """Create a tree object with nullsha hash"""
    git_objects_dir = ".git/objects"
    nullsha_dir = os.path.join(git_objects_dir, "00")
    nullsha_file = os.path.join(nullsha_dir, "00000000000000000000000000000000000001")
    
    os.makedirs(nullsha_dir, exist_ok=True)
    
    # Create a minimal tree object
    # Format: "tree <size>\0<entries>"
    # Tree entry format: <mode> <name>\0<20-byte-sha>
    content = b""
    header = f"tree {len(content)}\0".encode()
    store = header + content
    
    compressed = zlib.compress(store)
    
    with open(nullsha_file, 'wb') as f:
        f.write(compressed)
    
    print(f"Created nullsha tree at: {nullsha_file}")
    return nullsha_file

def create_additional_nullsha():
    """Create additional nullsha object"""
    git_objects_dir = ".git/objects"
    nullsha_dir = os.path.join(git_objects_dir, "00")
    nullsha_file = os.path.join(nullsha_dir, "00000000000000000000000000000000000002")

    os.makedirs(nullsha_dir, exist_ok=True)

    # Create another blob
    content = b"second nullsha entry"
    header = f"blob {len(content)}\0".encode()
    store = header + content

    compressed = zlib.compress(store)

    with open(nullsha_file, 'wb') as f:
        f.write(compressed)

    print(f"Created additional nullsha at: {nullsha_file}")
    return nullsha_file

if __name__ == "__main__":
    import sys
    if len(sys.argv) > 1 and sys.argv[1] == "more":
        create_additional_nullsha()
    else:
        create_nullsha_blob()
        create_nullsha_tree()
    print("\nNullsha objects created successfully!")

