# API Documentation

## Endpoints

### GET /api/users
Returns a list of all users.

### POST /api/users
Creates a new user.

### GET /api/users/:id
Returns a specific user by ID.

### DELETE /api/users/:id
Deletes a user by ID.

