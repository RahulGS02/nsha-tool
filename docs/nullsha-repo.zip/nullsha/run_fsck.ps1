# PowerShell script to run git fsck
Write-Host "Running git fsck..."
git fsck --full
Write-Host "`nDone!"

