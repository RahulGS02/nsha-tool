#!/usr/bin/env python3
"""
Script to verify nullsha entries exist in git object database
"""
import os
import zlib

def check_nullsha_objects():
    """Check if nullsha objects exist"""
    nullsha_dir = ".git/objects/00"
    
    print("=== Checking for nullsha objects ===\n")
    
    if not os.path.exists(nullsha_dir):
        print(f"Directory {nullsha_dir} does not exist!")
        return False
    
    files = os.listdir(nullsha_dir)
    # Check for files that start with 37 zeros (nullsha-like objects)
    nullsha_files = [f for f in files if len(f) == 38 and f.startswith('0' * 37)]
    
    if not nullsha_files:
        print("No nullsha objects found!")
        return False
    
    print(f"Found {len(nullsha_files)} nullsha object(s):\n")
    
    for filename in nullsha_files:
        full_sha = "00" + filename
        filepath = os.path.join(nullsha_dir, filename)
        
        print(f"✓ Nullsha object: {full_sha}")
        print(f"  Path: {filepath}")
        
        # Try to read and decompress the object
        try:
            with open(filepath, 'rb') as f:
                compressed = f.read()
                decompressed = zlib.decompress(compressed)
                
                # Parse git object header
                null_pos = decompressed.find(b'\x00')
                header = decompressed[:null_pos].decode('utf-8')
                content = decompressed[null_pos+1:]
                
                print(f"  Header: {header}")
                print(f"  Content: {content[:50]}..." if len(content) > 50 else f"  Content: {content}")
                print()
        except Exception as e:
            print(f"  Error reading object: {e}")
            print()
    
    return True

def check_git_commits():
    """Check number of commits"""
    try:
        import subprocess
        result = subprocess.run(
            ['git', 'rev-list', '--all', '--count'],
            capture_output=True,
            text=True,
            timeout=5
        )
        if result.returncode == 0:
            count = result.stdout.strip()
            print(f"\n=== Git Repository Info ===")
            print(f"Total commits: {count}")
            return True
    except:
        print("\nCould not get commit count (git command may be hanging)")
    return False

if __name__ == "__main__":
    success = check_nullsha_objects()
    check_git_commits()
    
    if success:
        print("\n" + "="*50)
        print("SUCCESS: Nullsha objects have been created!")
        print("="*50)
        print("\nTo verify with git fsck, run:")
        print("  git fsck --full")
        print("\nNote: git fsck may hang or show errors due to the")
        print("intentionally corrupted nullsha objects.")
    else:
        print("\nFAILED: No nullsha objects found!")

