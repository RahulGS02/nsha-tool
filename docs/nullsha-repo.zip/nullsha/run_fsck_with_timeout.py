#!/usr/bin/env python3
"""
Run git fsck with timeout to detect nullsha issues
"""
import subprocess
import sys

def run_fsck():
    print("="*70)
    print("Running: git fsck --full")
    print("="*70)
    print("(This may take a moment or timeout due to null SHA issues...)\n")
    
    try:
        process = subprocess.Popen(
            ['git', 'fsck', '--full'],
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            text=True
        )
        
        try:
            stdout, stderr = process.communicate(timeout=10)
            
            if stdout:
                print("=== STDOUT ===")
                print(stdout)
            
            if stderr:
                print("\n=== STDERR (Errors Found) ===")
                print(stderr)
                
        except subprocess.TimeoutExpired:
            process.kill()
            stdout, stderr = process.communicate()
            
            print("=== PARTIAL OUTPUT (timed out after 10s) ===\n")
            
            if stdout:
                print("STDOUT:")
                print(stdout)
            
            if stderr:
                print("\nSTDERR (Errors Found):")
                print(stderr)
            
            print("\n⚠️  Git fsck timed out - this is expected with null SHA issues")
    
    except Exception as e:
        print(f"Error: {e}")
    
    print("\n" + "="*70)
    print("Git fsck completed (or timed out)")
    print("="*70)

if __name__ == "__main__":
    run_fsck()

