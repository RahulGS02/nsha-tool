"""
Tests for authentication module
"""
import sys
sys.path.append('../src')
from auth import Auth

def test_register():
    auth = Auth()
    assert auth.register("user1", "pass123") == True
    assert auth.register("user1", "pass456") == False

def test_login():
    auth = Auth()
    auth.register("user1", "pass123")
    assert auth.login("user1", "pass123") == True
    assert auth.login("user1", "wrong") == False

