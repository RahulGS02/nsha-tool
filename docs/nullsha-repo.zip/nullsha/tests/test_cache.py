"""
Tests for cache module
"""
import sys
sys.path.append('../src')
from cache import Cache

def test_cache_operations():
    cache = Cache()
    cache.set("key1", "value1")
    assert cache.get("key1") == "value1"
    cache.delete("key1")
    assert cache.get("key1") is None

