#!/usr/bin/env python3
"""
Script to verify all nullsha issues in the repository
"""
import os
import subprocess

NULLSHA = "0000000000000000000000000000000000000000"

def check_references():
    """Check for null SHA in references"""
    print("\n" + "="*60)
    print("1. Checking References (branches, tags)")
    print("="*60)
    
    issues_found = []
    
    # Check branches
    refs_heads = ".git/refs/heads"
    if os.path.exists(refs_heads):
        for branch in os.listdir(refs_heads):
            path = os.path.join(refs_heads, branch)
            with open(path, 'r') as f:
                content = f.read().strip()
            
            if NULLSHA in content:
                print(f"   ✓ FOUND: Branch '{branch}' points to null SHA")
                issues_found.append(f"Branch {branch} -> {NULLSHA}")
            elif content == "":
                print(f"   ✓ FOUND: Branch '{branch}' is empty")
                issues_found.append(f"Branch {branch} is empty")
    
    # Check tags
    refs_tags = ".git/refs/tags"
    if os.path.exists(refs_tags):
        for tag in os.listdir(refs_tags):
            path = os.path.join(refs_tags, tag)
            with open(path, 'r') as f:
                content = f.read().strip()
            
            if NULLSHA in content:
                print(f"   ✓ FOUND: Tag '{tag}' points to null SHA")
                issues_found.append(f"Tag {tag} -> {NULLSHA}")
    
    return issues_found

def check_packed_refs():
    """Check packed-refs for null SHA"""
    print("\n" + "="*60)
    print("2. Checking Packed-refs")
    print("="*60)
    
    issues_found = []
    packed_refs = ".git/packed-refs"
    
    if os.path.exists(packed_refs):
        with open(packed_refs, 'r') as f:
            for line in f:
                if NULLSHA in line or "0000000000000000000000000000000000000001" in line:
                    print(f"   ✓ FOUND: {line.strip()}")
                    issues_found.append(line.strip())
    else:
        print("   No packed-refs file found")
    
    return issues_found

def check_head():
    """Check HEAD for null SHA"""
    print("\n" + "="*60)
    print("3. Checking HEAD")
    print("="*60)
    
    issues_found = []
    
    with open('.git/HEAD', 'r') as f:
        head_content = f.read().strip()
    
    if NULLSHA in head_content:
        print(f"   ✓ FOUND: HEAD points to null SHA: {head_content}")
        issues_found.append(f"HEAD -> {NULLSHA}")
    else:
        print(f"   HEAD: {head_content}")
    
    return issues_found

def check_objects():
    """Check for commits with null parents and trees with null entries"""
    print("\n" + "="*60)
    print("4. Checking Git Objects")
    print("="*60)
    
    issues_found = []
    
    # List all objects
    objects_dir = ".git/objects"
    for dir_name in os.listdir(objects_dir):
        if len(dir_name) == 2 and dir_name != "pack" and dir_name != "info":
            obj_dir = os.path.join(objects_dir, dir_name)
            if os.path.isdir(obj_dir):
                for obj_file in os.listdir(obj_dir):
                    sha = dir_name + obj_file
                    
                    # Check if it's a commit or tree by trying to read it
                    try:
                        result = subprocess.run(
                            ['git', 'cat-file', '-t', sha],
                            capture_output=True,
                            text=True,
                            timeout=2
                        )
                        obj_type = result.stdout.strip()
                        
                        if obj_type == "commit":
                            # Check commit content
                            result = subprocess.run(
                                ['git', 'cat-file', '-p', sha],
                                capture_output=True,
                                text=True,
                                timeout=2
                            )
                            if NULLSHA in result.stdout:
                                print(f"   ✓ FOUND: Commit {sha} contains null SHA")
                                issues_found.append(f"Commit {sha} has null SHA reference")
                        
                        elif obj_type == "tree":
                            # Trees with null entries will show errors in fsck
                            pass
                            
                    except:
                        pass
    
    return issues_found

def run_git_fsck():
    """Run git fsck to detect all issues"""
    print("\n" + "="*60)
    print("5. Running git fsck --full")
    print("="*60)
    
    try:
        result = subprocess.run(
            ['git', 'fsck', '--full'],
            capture_output=True,
            text=True,
            timeout=15
        )
        
        output = result.stdout + result.stderr
        
        if output:
            print(output)
        else:
            print("   No output from git fsck")
        
        return output
        
    except subprocess.TimeoutExpired:
        print("   Git fsck timed out (this may happen with null SHA issues)")
        return "TIMEOUT"
    except Exception as e:
        print(f"   Error running git fsck: {e}")
        return str(e)

if __name__ == "__main__":
    print("="*60)
    print("VERIFYING ALL NULLSHA ISSUES")
    print("="*60)
    
    all_issues = []
    
    all_issues.extend(check_references())
    all_issues.extend(check_packed_refs())
    all_issues.extend(check_head())
    all_issues.extend(check_objects())
    
    print("\n" + "="*60)
    print("SUMMARY OF ISSUES FOUND")
    print("="*60)
    print(f"\nTotal issues detected: {len(all_issues)}")
    for i, issue in enumerate(all_issues, 1):
        print(f"  {i}. {issue}")
    
    fsck_output = run_git_fsck()
    
    print("\n" + "="*60)
    print("✅ VERIFICATION COMPLETE")
    print("="*60)

