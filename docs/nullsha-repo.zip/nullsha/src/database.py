"""
Database connection module
"""

class Database:
    def __init__(self, host, port):
        self.host = host
        self.port = port
        self.connected = False
    
    def connect(self):
        print(f"Connecting to {self.host}:{self.port}")
        self.connected = True
    
    def disconnect(self):
        print("Disconnecting from database")
        self.connected = False

