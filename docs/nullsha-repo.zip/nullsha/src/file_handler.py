"""
File handling module
"""
import os

class FileHandler:
    @staticmethod
    def read_file(filepath):
        if os.path.exists(filepath):
            with open(filepath, 'r') as f:
                return f.read()
        return None
    
    @staticmethod
    def write_file(filepath, content):
        with open(filepath, 'w') as f:
            f.write(content)
        return True
    
    @staticmethod
    def delete_file(filepath):
        if os.path.exists(filepath):
            os.remove(filepath)
            return True
        return False

