"""
Middleware module
"""

class Middleware:
    def __init__(self):
        self.middlewares = []
    
    def use(self, func):
        self.middlewares.append(func)
    
    def execute(self, request):
        for middleware in self.middlewares:
            request = middleware(request)
        return request

