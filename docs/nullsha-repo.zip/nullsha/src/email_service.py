"""
Email service module
"""

class EmailService:
    def __init__(self, smtp_host, smtp_port):
        self.smtp_host = smtp_host
        self.smtp_port = smtp_port
    
    def send_email(self, to, subject, body):
        print(f"Sending email to {to}")
        print(f"Subject: {subject}")
        print(f"Body: {body}")
        return True
    
    def send_bulk_email(self, recipients, subject, body):
        for recipient in recipients:
            self.send_email(recipient, subject, body)

