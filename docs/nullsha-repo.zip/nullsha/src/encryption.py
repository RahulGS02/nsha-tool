"""
Encryption module
"""
import hashlib

class Encryption:
    @staticmethod
    def hash_password(password):
        return hashlib.sha256(password.encode()).hexdigest()
    
    @staticmethod
    def verify_password(password, hashed):
        return Encryption.hash_password(password) == hashed
    
    @staticmethod
    def encrypt(data, key):
        # Simple XOR encryption for demo
        return ''.join(chr(ord(c) ^ ord(key[i % len(key)])) for i, c in enumerate(data))

