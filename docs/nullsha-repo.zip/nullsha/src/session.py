"""
Session management module
"""
import uuid

class Session:
    def __init__(self):
        self.sessions = {}
    
    def create(self, user_id):
        session_id = str(uuid.uuid4())
        self.sessions[session_id] = {"user_id": user_id}
        return session_id
    
    def get(self, session_id):
        return self.sessions.get(session_id)
    
    def destroy(self, session_id):
        if session_id in self.sessions:
            del self.sessions[session_id]

