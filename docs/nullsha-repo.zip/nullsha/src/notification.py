"""
Notification module
"""

class Notification:
    def __init__(self):
        self.notifications = []
    
    def add(self, user_id, message):
        self.notifications.append({
            "user_id": user_id,
            "message": message,
            "read": False
        })
    
    def get_unread(self, user_id):
        return [n for n in self.notifications if n["user_id"] == user_id and not n["read"]]
    
    def mark_read(self, user_id):
        for n in self.notifications:
            if n["user_id"] == user_id:
                n["read"] = True

