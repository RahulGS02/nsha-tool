"""
Input validation module
"""

class Validator:
    @staticmethod
    def validate_email(email):
        return '@' in email and '.' in email
    
    @staticmethod
    def validate_password(password):
        return len(password) >= 8
    
    @staticmethod
    def validate_username(username):
        return len(username) >= 3 and username.isalnum()

