"""
Logging module
"""
import datetime

class Logger:
    def __init__(self, name):
        self.name = name
    
    def log(self, message, level="INFO"):
        timestamp = datetime.datetime.now().isoformat()
        print(f"[{timestamp}] [{level}] {self.name}: {message}")
    
    def info(self, message):
        self.log(message, "INFO")
    
    def error(self, message):
        self.log(message, "ERROR")

