"""
Router module
"""

class Router:
    def __init__(self):
        self.routes = {}
    
    def add_route(self, path, handler):
        self.routes[path] = handler
    
    def handle(self, path):
        handler = self.routes.get(path)
        if handler:
            return handler()
        return "404 Not Found"

