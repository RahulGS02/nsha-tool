#!/usr/bin/env python3
"""
Main application file
"""

def main():
    print("Hello, World!")
    print("This is the main application")

if __name__ == "__main__":
    main()

