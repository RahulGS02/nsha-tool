"""
API module for handling requests
"""

class API:
    def __init__(self, base_url):
        self.base_url = base_url
    
    def get(self, endpoint):
        url = f"{self.base_url}/{endpoint}"
        print(f"GET request to {url}")
        return {"status": "success"}
    
    def post(self, endpoint, data):
        url = f"{self.base_url}/{endpoint}"
        print(f"POST request to {url} with data: {data}")
        return {"status": "created"}

