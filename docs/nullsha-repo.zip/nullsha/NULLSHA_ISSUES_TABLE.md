# Nullsha Issues - Quick Reference Table

## Summary Table

| # | Issue Type | Object/Reference | SHA/Value | Location | Git fsck Error |
|---|------------|------------------|-----------|----------|----------------|
| 1 | Detached HEAD | HEAD | `0000...0000` | `.git/HEAD` | `error: HEAD: detached HEAD points at nothing` |
| 2 | Null Branch Ref | broken-branch | `0000...0000` | `.git/refs/heads/broken-branch` | `error: refs/heads/broken-branch: invalid sha1 pointer` |
| 3 | Empty Branch Ref | empty-branch | (empty) | `.git/refs/heads/empty-branch` | `error: refs/heads/empty-branch: invalid sha1 pointer` |
| 4 | Null Tag Ref | null-tag | `0000...0000` | `.git/refs/tags/null-tag` | `error: refs/tags/null-tag: invalid sha1 pointer` |
| 5 | Packed Ref (branch) | packed-null-branch | `0000...0000` | `.git/packed-refs` | `error: refs/heads/packed-null-branch?: invalid sha1 pointer` |
| 6 | Packed Ref (tag) | packed-null-tag | `0000...0000` | `.git/packed-refs` | `error: refs/tags/packed-null-tag?: invalid sha1 pointer` |
| 7 | Packed Ref (tag) | another-null-tag | `0000...0001` | `.git/packed-refs` | `error: refs/tags/another-null-tag?: invalid sha1 pointer` |
| 8 | Commit w/ Null Parent | commit | `5f3d6487...` | `.git/objects/5f/3d6487...` | `error: bogus commit object` |
| 9 | Tree w/ Null Entries | tree | `19bf955e...` | `.git/objects/19/bf955e...` | `warning: nullSha1: contains entries pointing to null sha1` |
| 10 | Missing Tree | commit | `94f0383e...` | `.git/objects/94/f0383e...` | `dangling commit` |

---

## Detailed Breakdown

### 1. HEAD Issues (1 issue)
- **Detached HEAD with null SHA**: `.git/HEAD` contains `0000000000000000000000000000000000000000`

### 2. Branch Reference Issues (2 issues)
- **broken-branch**: Points to null SHA
- **empty-branch**: Empty file (0 bytes)

### 3. Tag Reference Issues (1 issue)
- **null-tag**: Points to null SHA

### 4. Packed-refs Issues (3 issues)
- **packed-null-branch**: Branch in packed-refs pointing to null SHA
- **packed-null-tag**: Tag in packed-refs pointing to null SHA
- **another-null-tag**: Tag in packed-refs pointing to `0000...0001`

### 5. Commit Object Issues (2 issues)
- **Commit with null parent**: Commit `5f3d6487...` has parent `0000...0000`
- **Commit with missing tree**: Commit `94f0383e...` points to non-existent tree `1111...1111`

### 6. Tree Object Issues (1 issue)
- **Tree with null entries**: Tree `19bf955e...` contains 3 entries pointing to null SHA

---

## Git fsck Error Count

| Error Type | Count |
|------------|-------|
| `error: HEAD: detached HEAD points at nothing` | 1 |
| `error: refs/heads/...: invalid sha1 pointer` | 3 |
| `error: refs/tags/...: invalid sha1 pointer` | 3 |
| `error: bogus commit object` | 1 |
| `error: object could not be parsed` | 1 |
| `error: object 0000...0000 is a tree, not a blob` | 2 |
| `error in tree ...: broken links` | 1 |
| `warning in tree ...: nullSha1` | 1 |
| `warning in tree ...: zeroPaddedFilemode` | 1 |
| `error in tree ...: treeNotSorted` | 1 |
| `dangling commit` | 1 |
| `dangling tree` | 2 |
| `dangling blob` | 2 |

**Total Errors/Warnings**: 20+

---

## Object SHAs Reference

### Corrupted Commits
- `5f3d6487e4eefebf1e7cbc7c936e1450246614d9` - Commit with null parent
- `94f0383e390aed2679bcc38f8e891972e90c7740` - Commit with missing tree

### Corrupted Trees
- `19bf955e8d1f220ef28adac6aa1ee7185414b7d9` - Tree with null SHA entries

### Null SHA Values Used
- `0000000000000000000000000000000000000000` - Primary null SHA (used in 7+ places)
- `0000000000000000000000000000000000000001` - Secondary null SHA (used in 1 place)
- `1111111111111111111111111111111111111111` - Non-existent tree SHA

---

## Verification Commands

```bash
# Quick verification
python quick_verify.py

# Git fsck with timeout
python run_fsck_with_timeout.py

# Direct git fsck
git fsck --full

# Check HEAD
cat .git/HEAD

# Check branches
ls -la .git/refs/heads/
cat .git/refs/heads/broken-branch
cat .git/refs/heads/empty-branch

# Check tags
cat .git/refs/tags/null-tag

# Check packed-refs
cat .git/packed-refs

# Check specific objects
git cat-file -p 5f3d6487e4eefebf1e7cbc7c936e1450246614d9
git cat-file -p 19bf955e8d1f220ef28adac6aa1ee7185414b7d9
git cat-file -p 94f0383e390aed2679bcc38f8e891972e90c7740
```

---

## Files Created for Testing

| File | Purpose |
|------|---------|
| `create_nullsha_issues.py` | Creates all nullsha issues |
| `quick_verify.py` | Quick verification without git |
| `run_fsck_with_timeout.py` | Runs git fsck with timeout |
| `verify_all_issues.py` | Comprehensive verification |
| `NULLSHA_ISSUES_REPORT.md` | Detailed report |
| `COMPLETE_NULLSHA_GUIDE.md` | Complete guide |
| `NULLSHA_ISSUES_TABLE.md` | This file |

---

## ✅ All Issues Successfully Created!

**Total**: 10+ distinct nullsha issues  
**Git fsck errors**: 20+ errors/warnings detected  
**Status**: ✅ Complete and verified

