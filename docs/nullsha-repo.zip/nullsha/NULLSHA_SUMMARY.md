# Nullsha Git Repository - Summary

## Overview
This repository has been created with intentional nullsha entries in the git object database for testing purposes.

## Repository Statistics
- **Total Commits**: 17
- **Nullsha Objects Created**: 3
- **Nullsha Locations**: 
  - Around commit 5-6 (first set)
  - Around commit 11-12 (second set)

## Nullsha Objects

### 1. Nullsha Blob #1
- **SHA**: `0000000000000000000000000000000000000000`
- **Type**: blob
- **Path**: `.git/objects/00/00000000000000000000000000000000000000`
- **Content**: "nullsha test content"
- **Created**: After commit 5

### 2. Nullsha Tree
- **SHA**: `0000000000000000000000000000000000000001`
- **Type**: tree
- **Path**: `.git/objects/00/00000000000000000000000000000000000001`
- **Content**: Empty tree
- **Created**: After commit 5

### 3. Nullsha Blob #2
- **SHA**: `0000000000000000000000000000000000000002`
- **Type**: blob
- **Path**: `.git/objects/00/00000000000000000000000000000000000002`
- **Content**: "second nullsha entry"
- **Created**: After commit 11

## Verification

### Using git fsck
Run the following command to detect the nullsha entries:

```bash
git fsck --full
```

**Expected Output:**
```
error: 53c3a71e724708ba9390951bd78bc2c0f7492147: hash-path mismatch, found at: .git/objects/00/00000000000000000000000000000000000000
error: 4b825dc642cb6eb9a060e54bf8d69288fbee4904: hash-path mismatch, found at: .git/objects/00/00000000000000000000000000000000000001
error: 75bac6c9cf3bb0a16b43926fafb271d4a92b37aa: hash-path mismatch, found at: .git/objects/00/00000000000000000000000000000000000002
```

### Using Python Script
Run the verification script:

```bash
python verify_nullsha.py
```

This will show all nullsha objects and their details.

### Using PowerShell
List the nullsha directory:

```powershell
dir .git\objects\00
```

## Commit History

1. Commit 1: Initial commit with README
2. Commit 2: Add all source files
3. Commit 3: Add authentication module
4. Commit 4: Add cache module
5. Commit 5: Add validator module
6. **[NULLSHA CREATED]** - First set of nullsha objects
7. Commit 6: Add middleware module
8. Commit 7: Add router module
9. Commit 8: Add session management
10. Commit 9: Add auth tests
11. Commit 10: Add deployment guide
12. Commit 11: Add encryption module
13. **[NULLSHA CREATED]** - Second nullsha object
14. Commit 12: Add email service
15. Commit 13: Add notification system
16. Commit 14: Add file handler
17. Commit 15: Add email configuration
18. Commit 16: Add cache tests
19. Commit 17-18: Add remaining files

## Files and Folders Created

### Source Files (`src/`)
- main.py - Main application
- utils.py - Utility functions
- database.py - Database connectivity
- api.py - API endpoints
- logger.py - Logging system
- auth.py - Authentication
- cache.py - Caching system
- validator.py - Input validation
- middleware.py - Middleware
- router.py - Routing
- session.py - Session management
- encryption.py - Encryption utilities
- email_service.py - Email functionality
- notification.py - Notifications
- file_handler.py - File operations

### Documentation (`docs/`)
- guide.md - User guide
- api.md - API documentation
- deployment.md - Deployment guide
- architecture.md - Architecture overview

### Configuration (`config/`)
- settings.json - Application settings
- database.json - Database configuration
- email.json - Email configuration

### Tests (`tests/`)
- test_utils.py - Utility tests
- test_auth.py - Authentication tests
- test_cache.py - Cache tests

### Scripts
- create_nullsha.py - Script to create nullsha objects
- verify_nullsha.py - Script to verify nullsha objects
- check_nullsha.py - Script to check with git fsck
- run_fsck_timeout.py - Script to run fsck with timeout

## Important Notes

⚠️ **Warning**: The nullsha objects are intentionally corrupted git objects. They may cause:
- Git fsck to report errors (this is expected)
- Some git operations to behave unexpectedly
- Git commands to hang in certain situations

This repository is for **testing and educational purposes only**.

## How Nullsha Objects Were Created

The nullsha objects were created by:
1. Manually creating git object files in `.git/objects/00/` directory
2. Naming them with the nullsha hash (all zeros)
3. Compressing valid git object content using zlib
4. Writing the compressed data to the nullsha-named files

This creates a mismatch between the file path (which suggests SHA 0000...0000) and the actual content hash, which git fsck detects as "hash-path mismatch" errors.

