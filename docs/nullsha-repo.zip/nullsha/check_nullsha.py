#!/usr/bin/env python3
"""
Script to verify nullsha entries in git repository
"""
import subprocess
import os

def run_git_fsck():
    """Run git fsck and capture output"""
    try:
        print("Running git fsck --full...")
        result = subprocess.run(
            ['git', 'fsck', '--full'],
            capture_output=True,
            text=True,
            timeout=30
        )
        
        print("\n=== STDOUT ===")
        print(result.stdout)
        
        print("\n=== STDERR ===")
        print(result.stderr)
        
        # Check for nullsha in output
        combined_output = result.stdout + result.stderr
        if '0000000000000000000000000000000000000000' in combined_output:
            print("\n✓ Found nullsha (0000000000000000000000000000000000000000) in output!")
        else:
            print("\n✗ Nullsha not found in fsck output")
        
        # Check if nullsha files exist
        print("\n=== Checking nullsha files ===")
        nullsha_dir = ".git/objects/00"
        if os.path.exists(nullsha_dir):
            files = os.listdir(nullsha_dir)
            print(f"Files in {nullsha_dir}:")
            for f in files:
                print(f"  - {f}")
                if f.startswith("00000000000000000000000000000000000000"):
                    print(f"    ✓ This is a nullsha file!")
        
        return result.returncode
        
    except subprocess.TimeoutExpired:
        print("Git fsck timed out after 30 seconds")
        return -1
    except Exception as e:
        print(f"Error running git fsck: {e}")
        return -1

if __name__ == "__main__":
    exit_code = run_git_fsck()
    print(f"\nExit code: {exit_code}")

